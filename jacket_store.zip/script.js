
const cart = [];
const cartList = document.getElementById("cart");
const totalElement = document.getElementById("total");

document.querySelectorAll(".add-to-cart").forEach((button) => {
  button.addEventListener("click", () => {
    const name = button.dataset.name;
    const price = parseInt(button.dataset.price);

    cart.push({ name, price });
    updateCart();
  });
});

function updateCart() {
  cartList.innerHTML = "";
  let total = 0;

  cart.forEach((item, index) => {
    const li = document.createElement("li");
    li.innerHTML = `${item.name} - ${item.price} ₽ <button onclick="removeFromCart(${index})">Удалить</button>`;
    cartList.appendChild(li);
    total += item.price;
  });

  totalElement.textContent = total;
}

function removeFromCart(index) {
  cart.splice(index, 1);
  updateCart();
}

document.getElementById("checkout").addEventListener("click", () => {
  alert("Спасибо за покупку!");
  cart.length = 0;
  updateCart();
});
